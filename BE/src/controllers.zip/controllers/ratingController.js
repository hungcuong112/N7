const { Rating, Appointment, User } = require('../models');

// Bệnh nhân gửi đánh giá cho bác sĩ sau khi khám xong
exports.createRating = async (req, res) => {
  try {
    const patient = req.userInfo;
    const { appointmentId, score, comment } = req.body;

    // Kiểm tra appointment hợp lệ và đã completed, chưa đánh giá
    const appointment = await Appointment.findByPk(appointmentId);
    if (!appointment || appointment.patientId !== patient.id || appointment.status !== 'completed') {
      return res.status(400).json({ message: 'Lịch khám không hợp lệ hoặc chưa hoàn tất.' });
    }
    const existed = await Rating.findOne({ where: { appointmentId } });
    if (existed) return res.status(400).json({ message: 'Bạn đã đánh giá lịch khám này.' });

    // Tạo đánh giá
    const rating = await Rating.create({
      appointmentId,
      doctorId: appointment.doctorId,
      patientId: patient.id,
      score,
      comment
    });
    res.status(201).json({ message: 'Đánh giá thành công!', rating });
  } catch (err) {
    res.status(500).json({ message: 'Lỗi tạo đánh giá', error: err.message });
  }
};

// Lấy danh sách đánh giá của bác sĩ (bệnh nhân, bác sĩ, admin đều xem được)
exports.getDoctorRatings = async (req, res) => {
  try {
    const { doctorId } = req.params;
    const ratings = await Rating.findAll({
      where: { doctorId },
      include: [{ model: User, as: 'patient', attributes: ['id', 'fullName'] }],
      order: [['createdAt', 'DESC']]
    });
    // Tính điểm trung bình
    const avg = ratings.length ? (ratings.reduce((s, r) => s + r.score, 0) / ratings.length).toFixed(2) : null;
    res.json({ average: avg, total: ratings.length, ratings });
  } catch (err) {
    res.status(500).json({ message: 'Lỗi lấy đánh giá bác sĩ', error: err.message });
  }
};

// (Admin hoặc bác sĩ có thể xem thống kê tất cả đánh giá, bạn có thể bổ sung thêm API này)
